//>>built
define("dijit/form/nls/zh-tw/ComboBox",({previousMessage:"前一個選擇項",nextMessage:"其他選擇項"}));
