//>>built
define("dijit/nls/fr/common",({buttonOk:"OK",buttonCancel:"Annuler",buttonSave:"Enregistrer",itemClose:"Fermer"}));
