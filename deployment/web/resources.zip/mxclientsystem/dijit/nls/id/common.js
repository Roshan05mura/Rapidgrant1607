//>>built
define("dijit/nls/id/common",({buttonOk:"OK",buttonCancel:"Batal",buttonSave:"Simpan",itemClose:"Tutup"}));
